let fcircX = 0;
let fcircY = 0;
let scircX = 700;
let scircY = 0;
let fr = 30;
let clr;

function setup() {
createCanvas(700, 700);
background (35);
frameRate(fr);
clr = color(255, 0, 0);
}

function draw() {
  background(50);
  

colorMode(RGB, 255, 255, 255, 1);


let z1 = mouseX;
let z2 = mouseY;
let z3 = pmouseX;
let z4 = pmouseY;

let z5 = 350
let z6 = 350

let d = int(dist(z5, z2, z1, z2));

fill (0, 100, 0, 1);
ellipse(350, 350, pow(z3, .75), pow(z3, .75));

fill (25,25,25,1);
ellipse(z5, z6, 10, 10);

fill (0,0,100,1);
 ellipse(z3, z4, 35, 35);

 fill (200,100,50,1);
 ellipse(z1, z2, 40, 40);

fill (50,175,200,1);
text(nfc(d, 1), z1, z2);

//Cursor Circles




   fcircX = fcircX += 3; 
   fcircY = fcircY += 3;
  if (fcircX >= width) {
   // Off screen.
    fcircX = 0;
    fcircY = 0;
  }
  fill(clr);
  ellipse(fcircX, fcircY, 60, 60);

   scircX = scircX += -3; 
   scircY = scircY += 3;
  if (scircX <= length) {
   // Off screen.
    if (fr === 30) {
      clr = color(0, 255, 0);
      fr = 40;
      frameRate(fr);
    } else {
      clr = color(255, 0, 0);
      fr = 30;
      frameRate(fr);
      //Color Change
    }
    scircX = 700;
    scircY = 0;
  }
  fill(clr);
  ellipse(scircX, scircY, 60, 60);
}