k = 120;
k2 = 160;


function setup() {
 createCanvas(700,700);
 background(50);
  // Canvas
  
}

function draw() {
background(50);
colorMode(RGB,255,255,255,1);

if (keyIsPressed === true) {
	k = 255;
	k2 = 255;
} else {
	k = 120;
	k2 = 160;
}

ship(mouseX, 650);


for (var x = -20; x < width + 30; x += 30) {
translate(width / 8, height / 8);
translate(p5.Vector.fromAngle(millis() / 300, 3));
xeno(x,0);
}
print ("value of x for xeno loop is" + x);
  // put drawing code here
}


function ship(x,y) {

	push();
	translate(x,y)

	stroke(5);
	strokeWeight(2);
	fill(100,100,k,1);
	rect(-22.5,-20, 40,5);

	fill(100,100,k,1);
	rect(-10,-35, 15,40);

	fill(k2,120,100,1);
	rect(-10,-28, 15,5);
//center

	fill(100,100,k,1);
	rect(-15,-5, 5,15);

	fill(100,100,k,1);
	rect(-25,3, 10,20);

	fill(100,100,k,1);
	rect(-15,-30, 5,5);

	fill(100,100,k,1);
	rect(-20,-40, 5,15);
//left

	fill(100,100,k,1);
	rect(5,-5, 5,15);

	fill(100,100,k,1);
	rect(10,3, 10,20);

	fill(100,100,k,1);
	rect(5,-30, 5,5);

	fill(100,100,k,1);
	rect(10,-40, 5,15);
//right

	pop();
//Player Ship
}

function xeno(x,y) {
		push();
	translate(x,y)

	stroke(5);
	strokeWeight(2);

	fill(100,120,100,1);
	ellipse(-30,-35, 20,20);

	fill(100,120,100,1);
	ellipse(10,-35, 20,20);

	fill(50,60,50,1);
	rect(-18.5,-65, 18,15);

	fill(100,120,100,1);
	ellipse(-10,-35, 40,40);

	fill(160,80,100,1);
	rect(-17,-28, 15,5);

	fill(50,60,50,1);
	rect(-40,-47, 6,29);

	fill(50,60,50,1);
	rect(14,-47, 6,29);

	pop();
//xeno	
}