let vid;
function setup() {
  noCanvas();

  vid = createVideo(
    ['assets/comp.mp4', 'assets/comp.ogv', 'assets/comp.webm'],
    vidLoad
  );

  vid.size(500, 500);
}

// This function is called when the video loads
function vidLoad() {
  vid.loop();
  vid.volume(0);
}